import "./App.css";
import React, { useState, useEffect, useRef } from "react";
import "animate.css";
import HeaderQuickConnects from "./components/HeaderQuickConnects";
import NavigationIconsHeader from "./components/NavigationIconsHeader";
import FromTumblrToReactHeaderImg from "./components/FromTumblrToReactHeaderImg/FromTumblrToReactHeaderImg";
import NavigationIconsFooter from "./components/NavigationIconsFooter";
import HoverStrangeObservationsReveal from "./components/HoverStrangeObservationsReveal";
import GeneralNavigationIcon from "./components/GeneralNavigationIcon";

function App() {
  const [data, setData] = useState([]);
  const itemRefs = useRef([]);

  useEffect(() => {
    const jsonPath = `/captions-and-images.json?v=2025-09-10b`;
    fetch(jsonPath, { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        itemRefs.current = json.map(
          (_, i) => itemRefs.current[i] || React.createRef()
        );
      })
      .catch((err) => console.error("❌ Failed to load JSON:", err));
  }, []);

  const scrollToTop = () => {
    if (itemRefs.current[0]?.current) {
      itemRefs.current[0].current.scrollIntoView({ behavior: "smooth" });
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const scrollToBottom = () => {
    const last = itemRefs.current.length - 1;
    if (itemRefs.current[last]?.current) {
      itemRefs.current[last].current.scrollIntoView({ behavior: "smooth" });
    } else {
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
    }
  };

  const scrollToRandom = () => {
    const n = itemRefs.current.length;
    if (!n) return;
    const i = Math.floor(Math.random() * n);
    itemRefs.current[i]?.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="App">
      <HeaderQuickConnects />
      <NavigationIconsHeader
        onGoToBottom={scrollToBottom}
        onRandomSelect={scrollToRandom}
      />
      <FromTumblrToReactHeaderImg />
      <HoverStrangeObservationsReveal />

      <main style={{ maxWidth: 920, margin: "0 auto" }}>
        {data.map((item, idx) => (
          <React.Fragment key={item.image || idx}>
            <figure ref={itemRefs.current[idx]} style={{ margin: "36px 0" }}>
              <img
                src={item.image}
                alt={item.caption || ""}
                loading="lazy"
                style={{
                  display: "block",
                  margin: "0 auto",
                  /* preserve aspect ratio, never crop */
                  width: "auto",
                  maxWidth: "100%",
                  height: "auto",
                  /* cap tall images without cropping */
                  maxHeight: "min(70vh, 680px)",
                  /* objectFit 'contain' is safe, but width/height auto already preserves AR */
                  objectFit: "contain",
                }}
              />
              {item.caption && (
                <figcaption
                  style={{
                    textAlign: "center",
                    marginTop: 8,
                    fontFamily: "Futura, Trebuchet MS, Arial, sans-serif",
                  }}
                >
                  {item.caption}
                </figcaption>
              )}
            </figure>

            {/* Show the nav chevron after the 10th photo */}
            {idx === 9 && <GeneralNavigationIcon action={scrollToTop} />}
          </React.Fragment>
        ))}
      </main>

      <NavigationIconsFooter
        onGoToTop={scrollToTop}
        onRandomSelect={scrollToRandom}
      />
    </div>
  );
}

export default App;
